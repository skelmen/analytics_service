export default {
    authToken: process.env.AUTH_TOKEN,
};
