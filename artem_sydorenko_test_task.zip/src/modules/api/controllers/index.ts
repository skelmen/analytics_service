import { AppController } from './app.controller';

export const API_CONTROLLERS = [
    AppController,
];